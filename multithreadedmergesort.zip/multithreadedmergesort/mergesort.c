/*Victor Oyefusi voyefusi 108402485*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <err.h>
#include <pthread.h>
#include "mergesort.h"
#include <sysexits.h>

static Chunk *head;
static int flag = 0;
static int amount_chunks = 0;
static int chunk_counter = 0;
static void *merge(void *first, void *second, size_t num_elem, size_t elem_size, Compare_fn cmp);
void chunk_merge(struct Chunk *first, struct Chunk*second, size_t elem_size, Compare_fn cmp, int max_chunk_size);
void clean_up(struct Chunk *first, size_t elem_size, Compare_fn cmp, int max_chunk_size);
static void *do_work(void *arg);
static void add_to_queue(struct Chunk *chunk);
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/*struct that holds parameters for pthread function call*/
struct args {
  size_t num_elem;
  int chunk_size;
  size_t elem_size;
  Compare_fn cmp;
  Chunk *chunk;
  int num_threads;
}args;

/*once two buddies have been made, they are merged in this function by doubling
the size of the first parameter and setting the first parameters first to be
equal to the lesser ->first*/
void chunk_merge(struct Chunk *first, struct Chunk*second, size_t elem_size, Compare_fn cmp, int max_chunk_size){
  int compare = first->first - second->first;
  if(compare < 0){/*first is the first buddy*/
    first->done = 0;
    first->size = first->size * 2;
    if(first->size == max_chunk_size){
      first->done = 1;
      second->done = 2;
      first->next = NULL;
    }
  }else{/*first is the second buddy. change first->first to second->first*/
    first->first = second->first;
    first->done = 0;
    first->next = NULL;
    first->size = first->size * 2;
    if(first->size == max_chunk_size){
      first->done = 1;
      second->done = 2;
    }
  }
}

/*this funtion called when all chunks are in queue
  and buddies have not been completely merged*/
void clean_up(Chunk *first_chunk,  size_t elem_size, Compare_fn cmp, int max_chunk_size){
  Chunk* curr = head;  
  int buddy_first = (first_chunk->first % (2 * first_chunk->size))
    ? (first_chunk->first - first_chunk->size)
    : (first_chunk->first + first_chunk->size);
  
  if(head!=NULL){
    while(curr){
      if((buddy_first == curr->first)&&(curr->done!=2)){
	chunk_merge(first_chunk, curr, elem_size, cmp, max_chunk_size);
	break;
      }else{
	curr = curr->next;
      }
    }
  }
}

/*responsible for initializing chunks and calling worker threads, which
  call do_work to sort and merge chunks*/
void mt_mergesort(void *arr, size_t num_elem, int chunk_size, size_t elem_size, Compare_fn cmp, int num_threads){
  int index;
  Chunk *chunk;
  struct args *temp = malloc(sizeof(args)+1);
  pthread_t *tids =  malloc(sizeof(pthread_t)*num_threads);  
  int total_chunks = num_elem/chunk_size;
  amount_chunks = total_chunks;
  chunk = calloc((size_t)total_chunks, sizeof(Chunk));
  if(chunk == NULL){
    fprintf(stderr, "Unable to allocate memory. Error EX_OSERR");
    exit(EX_OSERR);
  }
  /*returns if these initial conditions are reached*/
  if((num_threads < 1) || (num_threads > 1024)
     || (chunk_size < 1) || (chunk_size > 1073741824)){
    return; 
  }
  for(index = 0;index < total_chunks;index++){   
  
    chunk[index].size = chunk_size;
    chunk[index].arr = arr;
    chunk[index].first = index*chunk_size;
    chunk[index].done = 0;
    
    temp->elem_size = elem_size;
    temp->chunk = &chunk[index];
    temp->num_elem = num_elem;
    temp->chunk_size = chunk_size;
    temp->cmp = cmp;
    temp->num_threads = num_threads;
    
    if(pthread_create(&tids[index], NULL, do_work, temp)){
      err(EX_OSERR, "thread error");
    }
    if(pthread_join(tids[index], NULL)){
      err(EX_OSERR, "thread error"); 
    }
  }
  
  free(tids);
  free(temp);
  free(chunk);
}

/*threads utilize this function. mutual exclusion is established within
  this function to ensure threads do not intefere with each others processes.
  works with task queue of chunks. Chunk added to queue checks the rest of queue
  for associated buddy. If it is found, then then the buddies are merged. 
*/
void* do_work(void *arg){
  struct args *temp = (struct args*)arg;
  struct Chunk *first_chunk = NULL;
  struct Chunk *curr = NULL;
  int buddy_first;
  int curr_done = 0;
  
  /*establish mutual exclusion*/
  pthread_mutex_lock(&mutex);
  add_to_queue(temp->chunk);
  if(chunk_counter == amount_chunks){
    flag = 1;
  }
  
  /*set pointer to first element and head to next chunk*/
  first_chunk= head;
  head = head->next;
  curr = head;
  
  /*sort first unsorted chunk*/
  st_mergesort((((char*)first_chunk->arr) + ((temp->elem_size)*(first_chunk->first))),
	       first_chunk->size, temp->elem_size, temp->cmp);
 
  first_chunk->done = 1;
  do{
    if((flag == 1)&&(first_chunk->size != temp->num_elem)){
      while(first_chunk->size != temp->num_elem){
	clean_up(first_chunk, temp->elem_size, temp->cmp, temp->num_elem);
	st_mergesort((((char*)first_chunk->arr) + ((temp->elem_size)*(first_chunk->first)))
		     , first_chunk->size, temp->elem_size, temp->cmp);
      }
   }
while(curr){
  /*we want to check find the buddy of first_chunk and if that buddy
    is not done, we place the first_chunk back in queue.*/
  buddy_first = (first_chunk->first % (2 * first_chunk->size))
    ? (first_chunk->first - first_chunk->size)
    : (first_chunk->first + first_chunk->size);
  
  if((buddy_first == curr->first)&&(curr->done!=2)){
    /*if buddy is done merge and exit loop*/
    if(curr->done == 1){
      chunk_merge(first_chunk, curr, temp->elem_size, temp->cmp, temp->num_elem);
      break;
    }else{
      /*exit loop if buddy found is not done*/
      break;
    }
  }else{
    /*increment current pointer*/
    curr = curr->next;
  }    
 }
/*curr at the end of queue so we add first_chunk back to queue*/
 if(head == NULL){
   head = first_chunk;
   head->next = NULL;
 }else{
   first_chunk->next = head;
   head = first_chunk;
 }
 
 /*if first chunk has been merged with buddy, we sort that new merged buddy*/
 if(first_chunk != NULL){
   if(first_chunk->done && curr_done){
     st_mergesort((((char*)first_chunk->arr) + ((temp->elem_size)*(first_chunk->first)))
		  , first_chunk->size, temp->elem_size, temp->cmp);
     break;
   }
 }
 /*once all chunks are in queue, this condition forces a loop until
   one chunk has the same size as the original array*/
  }while((first_chunk->size != temp->num_elem) && (flag == 1));
  
  pthread_mutex_unlock(&mutex);   
  pthread_exit(NULL);
}

/*dynamically created 3 arrays of char pointers. one copys the original array,
 and the other two split the original array into two parts. this function uses
recursion to implement the mergesort algorithm.*/
void st_mergesort(void *arr, size_t num_elem, size_t elem_size, Compare_fn cmp){
  char* array1 = malloc((elem_size * (num_elem/2))+1);
  char* array2 = malloc((((num_elem/2)+(num_elem%2))*elem_size)+1); 
  char* arr_copy = malloc((num_elem * elem_size)+1);
  char* arr_merge;
  memmove(arr_copy, (char*)arr, (num_elem * elem_size));

  /*if this condition reached, arr can no longer be sorted. returns*/
  if(num_elem <= 1){
    return;
  }
  
  memmove(array1, arr_copy, elem_size*(num_elem/2));
  memmove(array2, (char*)(arr_copy + elem_size*(num_elem/2)), ((((num_elem/2)+(num_elem%2))*elem_size)+1));
  
  st_mergesort(array1, num_elem/2, elem_size, cmp);/*mergesort first half*/
  st_mergesort(array2,((num_elem/2)+(num_elem%2)), elem_size,  cmp);/*mergesort second half*/
  
  arr_merge = merge(array1, array2, num_elem, elem_size, cmp);
  memmove((char*)arr, arr_merge, num_elem * elem_size);
  
  free(array1);
  free(array2);
  free(arr_copy);
  free(arr_merge);
  return;
}

/*add chunk to front of queue*/
void add_to_queue(struct Chunk *chunk){
  if(chunk_counter == 0){
    head = chunk;
    chunk_counter++;
  }else{
    chunk->next = head;
    head = chunk;
    chunk_counter++;
  }
}

/*takes two void array parameters and sorts them via the merging step in the
  mergesort algorithm. returns a sorted and merged void array*/
void *merge(void *first, void *second, size_t num_elem, size_t elem_size, Compare_fn cmp){
  int i, j, k, compare;
  char* ptr_merge = malloc((num_elem * elem_size)+elem_size);
  char* firstc = first;
  char* secondc = second;
  char* temp1 = malloc(elem_size);
  char* temp2 = malloc(elem_size);
  /*if one array is at the end, ptr_merge gets the rest of the values from
    the  other array*/
  for(i = 0, j = 0, k = 0;k < num_elem * elem_size;){
    if(i >= (num_elem/2)*elem_size){
      memmove(ptr_merge + k, secondc + j, elem_size);
      k = k + elem_size;
      j = j + elem_size;
      continue;
    }
    
    if( j >= ((num_elem/2)+(num_elem%2))*elem_size){
      memmove(ptr_merge + k, firstc + i, elem_size);
      k = k + elem_size;
      i = i + elem_size;
      continue;
    }
    /*compare values in arrays. lesser value gets added to ptr_merge*/
    /*typedef int (*Compare_fn)(const void *, const void *);*/   
    memmove(temp1, firstc + i, elem_size);
    memmove(temp2, secondc + j, elem_size);
    
    compare = (*cmp)(temp1, temp2);
    
    if(compare < 0){/*add first to array*/
      memmove(ptr_merge + k, firstc + i, elem_size);
      i = i + elem_size;
      k = k + elem_size;
    }else if(compare > 0){/*add second to array*/
      memmove(ptr_merge + k, secondc + j, elem_size);
      j = j + elem_size;
      k = k + elem_size;
    }else{/*compared values the same. add both*/
      memmove(ptr_merge + k, firstc + i, elem_size);
      k = k + elem_size;
      i = i + elem_size;
      memmove(ptr_merge + k, secondc + j, elem_size);
      j = j + elem_size;
      k = k + elem_size;
    }
    }
  free(temp1);
  free(temp2);
  return ptr_merge;
}
